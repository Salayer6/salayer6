#  <img src="https://cdn.discordapp.com/emojis/840660947596214302.gif?v=1" width="30px"> Hey there, I'm [Ekansh](https://www.youtube.com/watch?v=dQw4w9WgXcQ) <img src="https://cdn.discordapp.com/emojis/840660949371453520.gif?v=1" width="30px">

## <img src="https://cdn.discordapp.com/emojis/689204979419971689.gif?v=1" width="30px"> About me -
[He/Him] ♡
Student •  Bot Dev •  Mac and Cheese enthusiast and Professional fun haver.
Occasionally exists~  („• ֊ •„)

<a href="https://dsc.gg/inb">
  <img align="left" alt="Discord" width="23px" src="https://raw.githubusercontent.com/peterthehan/peterthehan/master/assets/discord.svg" />

<a href="https://twitter.com/EkanshLive">
  <img align="left" alt="Twitter" width="23px" src="https://raw.githubusercontent.com/peterthehan/peterthehan/master/assets/twitter.svg" />

<a href="https://www.reddit.com/u/LiveEkansh3392">
  <img align="left" alt="Reddit" width="23px" src="https://raw.githubusercontent.com/peterthehan/peterthehan/master/assets/reddit.svg" />

<a href="https://open.spotify.com/user/i5fzbt6g2q90wojkesnqx0gqv?si=06e226bd867c45ca">
  <img align="left" alt="Spotify" width="23px" src="https://raw.githubusercontent.com/peterthehan/peterthehan/master/assets/spotify.svg" />

<a href="https://www.youtube.com/channel/UCS6t-VigVblKcHhjdtBnE4w">
  <img align="left" alt="Youtube" width="23px" src="https://raw.githubusercontent.com/peterthehan/peterthehan/master/assets/youtube.svg" />

<a href="https://steamcommunity.com/profiles/76561199075562084">
  <img align="left" alt="Steam" width="23px" src="https://raw.githubusercontent.com/peterthehan/peterthehan/master/assets/steam.svg" />

![Profile Visits](https://komarev.com/ghpvc/?username=Dinav69&color=yellow&label=Profile-Visits&width=26px)

</a>

## I'm a Discord Developer! <img src="https://cdn.discordapp.com/emojis/840660945877729320.gif?v=1" width="30px">

- <img src="https://cdn.discordapp.com/emojis/752920935077511178.png?v=1" width="15px"> I’m currently learning typescript
- <img src="https://cdn.discordapp.com/emojis/752920935077511178.png?v=1" width="15px"> I’m looking to collaborate with other content creators
- <img src="https://cdn.discordapp.com/emojis/752920935077511178.png?v=1" width="15px"> I have made many discord bots.
- <img src="https://cdn.discordapp.com/emojis/752920935077511178.png?v=1" width="15px"> Fun fact: I love to play games and my favourite game is Detroit : become human :D

<a href="https://discord.com/users/720857179313274931">
<img height="80px" src="https://discord.c99.nl/widget/theme-3/720857179313274931.png" />
</a>

<a href="https://discord.com/users/720857179313274931">
<img height="400px"  src="https://camo.githubusercontent.com/b40aa6e0a49e00065a11b3773f9f4d7098be2fed4da538a0a32abb74992a7869/68747470733a2f2f726973686176616e616e642e6769746875622e696f2f7374617469632f696d616765732f6772656574696e67732e676966" />
</a>



## Spotify Playing <img src="https://cdn.discordapp.com/emojis/574830750180966400.gif?v=1" width="20px">

[![Spotify](https://novatorem.vercel.app/api/spotify)](https://open.spotify.com/user/i5fzbt6g2q90wojkesnqx0gqv)


[//]: <> (The `&nbsp;` is to have Aphelion take up more space)
[//]: <> (Old Visits: https://badges.pufler.dev/visits/novatorem/novatorem?logo=GitHub&label=github%20visits&color=336699&logoColor=white&style=flat-square)

<details>
  <summary>:zap: Recent GitHub Activity</summary>
  
<!--START_SECTION:activity-->
1. 🎉 committed in [LiveEkansh/Superb-bots](https://github.com/LiveEkansh/Superb-Bots)
<!--END_SECTION:activity-->

</details>

<details>
  <summary>:zap: GitHub Stats</summary>

![Ekansh's GitHub Stats](https://github-readme-stats.vercel.app/api?username=LiveEkansh&show_icons=true&theme=react)
  </details>

<details>
  <summary>:zap: Languages </summary>
<img src="https://cdn.discordapp.com/emojis/840660945877729320.gif?v=1" width="20px"> I mostly use Javascript to create bots but sometimes i use html or css for websites. I code on VSCode and Repl.it!

[![Ekansh's Stats](https://github-readme-stats.vercel.app/api/top-langs/?username=LiveEkansh&layout=compact&theme=midnight-purple)](https://github.com/LiveEkansh)
</div>
  </details>
</details
